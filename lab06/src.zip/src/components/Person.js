import { IonAvatar, IonButton, IonImg, IonItem, IonLabel } from "@ionic/react";
import { toggleFollowing } from "../store/PeopleStore";
const Person = ({ person }) => {
  return (
    <IonItem>
      <IonAvatar >
          <IonImg src={person.avatar.src}></IonImg>
      </IonAvatar>
      <IonLabel className="ion-padding-start">
          <h1>{person.name}</h1>
          <p>{person.surname}</p>
      </IonLabel>
      <IonButton
        color="primary"
        fill={person.following ? "solid" : "outline"}
        onClick={() => toggleFollowing(person.id)}
      >
        {person.following ? "Following" : "Follow"}
      </IonButton>
    </IonItem>
  );
};
export default Person;