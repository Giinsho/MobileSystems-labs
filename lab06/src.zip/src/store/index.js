export { default as PeopleStore } from "./PeopleStore";
