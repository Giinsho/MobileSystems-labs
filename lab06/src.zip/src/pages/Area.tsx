import { IonIcon } from "@ionic/react";
import React from 'react';  

import {useState, useRef} from "react";
import "./Area.css";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonInput,
  IonTitle,
  IonButton,
  IonItem,
  IonLabel,
  IonRow,
  IonCol,
  IonAlert
} from "@ionic/react";
import { Controller, useForm } from 'react-hook-form';
import { colorFill } from "ionicons/icons";
const Area: React.FC = () => {
    const wynikRef = useRef<HTMLIonInputElement>(null);
    const [obliczone, setObliczone] = useState<string>('');
    const { control, handleSubmit } = useForm();
    const [state, setState] = useState<any>({
        bok1: "",
        bok2: "",
        bok3: "",
        bok4: "",
        kat1: "",
        kat2: "",
      });
      const [alertShow, setAlert] = useState(false);


    const change = (e: any) => {
      setState({
          ...state,
        [e.target.name]: e.target.value,
      });
    };

    const metodaForm = (e: any) => {
        e.preventDefault();
        console.log(state)
        oblicz()
    };

    const oblicz = () =>{
        let sin1 = Math.sin((state.kat1*2*Math.PI)/360)
        let sin2 = Math.sin((state.kat2*2*Math.PI)/360)
   
        let wynik = eval("1/2*"+state.bok1+"*"+state.bok2+"*"+sin1+"+ 1/2*"+state.bok3+"*"+state.bok4+"*"+sin2)
        if(wynik.toString() == "Infinity"){
            setAlert(true)
            wynik = 0;
        }
        setObliczone(wynik.toString());
    }
    return (
      <IonPage>
        <IonHeader>
          <IonToolbar></IonToolbar>
        </IonHeader>
        <IonContent fullscreen>
          <IonHeader collapse="condense">
            <IonToolbar>
            <IonAlert
            isOpen={alertShow}
            onDidDismiss={() => setAlert(false)}
            cssClass='my-custom-class'
            header={'Alert'}
            subHeader={'Subtitle'}
            message={'You cannot divide by 0'}
            buttons={['Ok']}
            />
              <IonTitle size="large">Pole czworokąta</IonTitle>
            </IonToolbar>
          </IonHeader>

          <form className="ion-padding" onSubmit={metodaForm}>
          <IonLabel>Boki</IonLabel>
            <IonItem color="tertiary">
                <IonInput
                placeholder="Bok pierwszy"
                type="number"
                
                onIonChange={change}
                name="bok1"
                ></IonInput>
            </IonItem>

            <IonItem color="tertiary">
                <IonInput
                placeholder="Bok drugi"
                type="number"
              
                onIonChange={change}
                name="bok2"
                ></IonInput>
            </IonItem>

            <IonItem color="tertiary">
                <IonInput
                placeholder="Bok trzeci"
                type="number"
              
                onIonChange={change}
                name="bok3"
                ></IonInput>
            </IonItem>
           
            <IonItem color="tertiary">
                <IonInput
                placeholder="Bok czwarty"
                type="number"
              
                onIonChange={change}
                name="bok4"
                ></IonInput>
            </IonItem>
           
            <br/>
            <IonLabel>Kąty</IonLabel>
            <IonItem color="tertiary">
                <IonInput
                placeholder="Kąt pierwszy"
                type="number"
             
                onIonChange={change}
                name="kat1"
                ></IonInput>
            </IonItem>

            <IonItem color="tertiary">
                <IonInput
                placeholder="Kąt przeciwległy"
                type="number"
             
                onIonChange={change}
                name="kat2"
                ></IonInput>
            </IonItem>

            <br />
            <IonButton className="ion-margin-top" type="submit" expand="block">Oblicz</IonButton>
            <IonRow className="row">
            <IonCol >
              <IonItem color="tertiary"> 
                <IonLabel position='floating'><h2>Pole czworokąta:</h2></IonLabel>
                <br/>
                <br/>
                <IonInput ref={wynikRef}>{obliczone}</IonInput>
              </IonItem>
            </IonCol>
          </IonRow>
          </form>
       
          
         

        </IonContent>
   
      </IonPage>
    );
  
}
export default Area;
