import { 
  IonContent,
  IonHeader, 
  IonPage,
  IonTitle,
  IonToolbar,
  IonList,
  IonImg,
  IonItem,
  IonLabel
 } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab3.css';
import  obrazek1 from "../img/1.png";
import  obrazek2 from "../img/2.png";
import  obrazek3 from "../img/3.png";

const Tab3: React.FC = () => {

  type Item = {
    src: string;
    text: string;
   };
  const img1: Item = {
    src: obrazek1,
    text: "XD1"
  };

  const img2: Item = {
    src: obrazek2,
    text: "XD2"
  };

  const img3: Item = {
    src: obrazek3,
    text: "XD3"
  };
   const items: Item[] = [img1,img2,img3] 
   
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Tab 3</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Tab 3</IonTitle>
          </IonToolbar>
        </IonHeader>
        <ExploreContainer name="Tab 3 page" />

        <IonList>

            {items.map((image, i) => (
              <IonItem key={i}>
                  <IonImg src={image.src}></IonImg>
                  <IonLabel>{image.text}</IonLabel>
              </IonItem>
            ))}

        </IonList>
        
      </IonContent>
    </IonPage>
  );
};

export default Tab3;
