import { useState} from 'react';
import { IonApp,  setupIonicReact } from '@ionic/react';
import {  IonIcon,IonCardContent, IonAlert,IonPage, IonCard,IonButton,IonHeader,IonContent, IonToolbar,IonTitle,IonRow, IonCol, IonItem, IonLabel, IonInput } from '@ionic/react';

import React, {useRef} from 'react';  

// import { IonReactRouter } from '@ionic/react-router';
// import Home from './pages/Home';

/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';

/* Theme variables */
import '../theme/variables.css';

setupIonicReact();

const Kalkulator: React.FC = () => {
  
  const wynikRef = useRef<HTMLIonInputElement>(null);
  const dodajRef = useRef<HTMLIonInputElement>(null);
  const [obliczone, setObliczone] = useState<string>('');
  const [alertShow, setAlert] = useState(false);

  const dodaj = (wartosc: string) => {
      setObliczone(obliczone + wartosc);
  }
  const oblicz = () => {

    
    let wynik = eval(obliczone.toString())
    if(wynik.toString() == "Infinity"){
      setAlert(true)
      wynik = 0;
    }
    console.log(wynik)
    setObliczone(wynik.toString());
  };

  const resetuj = () => {
    wynikRef.current!.value = ''
    setObliczone("");
  };
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Zad 1 Kalkulator
          <IonAlert
          isOpen={alertShow}
          onDidDismiss={() => setAlert(false)}
          cssClass='my-custom-class'
          header={'Alert'}
          subHeader={'Subtitle'}
          message={'You cannot divide by 0'}
          buttons={['Ok']}
        />
          </IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent className='ion-padding'>
          <IonRow>
            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('1')}>
                1
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('2')}>
                2
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('3')}>
                3
              </IonItem>
            </IonCol>

          </IonRow>

          <IonRow>
            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('4')}>
                4
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('5')}>
                5
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('6')}>
                6
              </IonItem>
            </IonCol>
            
          </IonRow>

          <IonRow>
            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('7')} >
                7
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('8')}>
                8
              </IonItem>
            </IonCol>

            <IonCol className='ion-text-left' >
              <IonItem onClick = {() => dodaj('9')}>
                9
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>

            <IonCol>
              <IonItem onClick = {() => dodaj('0')}>
                0
              </IonItem>
            </IonCol>

            <IonCol>
              <IonItem onClick = {() => dodaj('+')}>
                +
              </IonItem>
            </IonCol>

            <IonCol>
              <IonItem onClick = {() => dodaj('-')}>
                -
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem onClick = {() => dodaj('*')}>
                *
              </IonItem>
            </IonCol>

            <IonCol>
              <IonItem  onClick = {() => dodaj('/')}>
                /
              </IonItem>
            </IonCol>
            
            <IonCol>
              <IonItem >
                <IonButton onClick = {oblicz}>
                     Oblicz
                </IonButton>
              </IonItem>
            </IonCol>
  
          </IonRow>

          <IonRow>
            <IonCol className='ion-text-right'>
              <IonItem>
                <IonLabel position='floating'><h2>{obliczone}</h2></IonLabel>
                <IonInput ref={wynikRef}></IonInput>
              </IonItem>
            </IonCol>
          </IonRow>
          
          <IonRow>
            <IonCol className='ion-text-right'>
                <IonButton onClick = {resetuj}>
       
                 Resetuj
                </IonButton>
            </IonCol>
          </IonRow>
        
      </IonContent>
     
    </IonPage>
  )
};
 

export default Kalkulator;
