import { IonContent, IonHeader,IonInput ,IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';
import { useState } from 'react';

const Tab1: React.FC = () => {
  const [numberA, setNumberA] = useState<number>();
  const [numberB, setNumberB] = useState<number>();
  const [numberC, setNumberC] = useState<number>();
  const [numberD, setNumberD] = useState<number>();

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Tab 1</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonInput type="number" value={numberA} placeholder="Enter Number  A"></IonInput>
        <IonInput type="number" value={numberB} placeholder="Enter Number  B"></IonInput>
        <IonInput type="number" value={numberC} placeholder="Enter Number  C"></IonInput>
        <IonInput type="number" value={numberD} placeholder="Enter Number  D"></IonInput>
      </IonContent>

    </IonPage>
  );
};

export default Tab1;
