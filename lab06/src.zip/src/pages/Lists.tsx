import { IonContent, IonHeader,IonInput ,IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';
import { useState } from 'react';
import { PeopleStore } from '../store';
import  Person  from "../components/Person";
import { getPeople } from '../store/Selectors';
import { useStoreState } from 'pullstate';


const Lists: React.FC = () => {
  const people = useStoreState(PeopleStore, getPeople);

  console.log(people);
  return (
    <IonPage>
         <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Lists</IonTitle>
          </IonToolbar>
        </IonHeader>
      <IonHeader>

        <IonToolbar>
          <IonTitle>Lists</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
              { people.map((person, index) => {
        return <Person person={ person } key={ index } />;
        })}

      </IonContent>
    </IonPage>
  );
};

export default Lists;

