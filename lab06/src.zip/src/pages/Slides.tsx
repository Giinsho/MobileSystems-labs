import {
  IonContent,
  IonHeader,
  IonInput,
  IonPage,
  IonTitle,
  IonToolbar,
  IonSlides,
  IonSlide,
  IonButton,
  IonItem,
  IonImg,
  IonLabel,
} from "@ionic/react";
import ExploreContainer from "../components/ExploreContainer";
import "./Tab1.css";
import { useState, useRef } from "react";
import obrazek1 from "../img/1.png";
import obrazek2 from "../img/2.png";
import obrazek3 from "../img/3.png";
const Slides: React.FC = () => {
  const slidesRef = useRef<any>();
  const [slideChange, setChange] = useState<any>();
  const [disablePrev, setDisablePrev] = useState(true);
  const [disableNext, setDisableNext] = useState(false);
  
  const opts = {
    initialSlide: 0,
    speed: 300,
  };

  const onBtnClicked = async (direction: string) => {
    const swiper = await slidesRef.current.getSwiper();
    if (direction === "next") {
      swiper.slideNext();
    } else if (direction === "prev") {
      swiper.slidePrev();
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Slides lab 6</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent fullscreen>
      <IonButton
          disabled={slidesRef.current?.isBeginning}
          onClick={() => onBtnClicked("prev")}
        >
          PREV
        </IonButton>
        <IonButton
          disabled={slidesRef.current?.isEnd}
          onClick={() => onBtnClicked("next")}
        >
          NEXT
        </IonButton>

        <IonSlides
          options={opts}
          ref={slidesRef}
          onIonSlideDidChange={slideChange}
        >
          <IonSlide>
            <IonItem>
              <IonImg src={obrazek1}></IonImg>
              <IonLabel>Obrazek 1</IonLabel>
            </IonItem>
          </IonSlide>
          
          <IonSlide>
            <IonItem>
              <IonImg src={obrazek2}></IonImg>
              <IonLabel>Obrazek 2</IonLabel>
            </IonItem>
          </IonSlide>
          <IonSlide>
            <IonItem>
              <IonImg src={obrazek3}></IonImg>
              <IonLabel>Obrazek 3</IonLabel>
            </IonItem>
          </IonSlide>
        </IonSlides>

    
      </IonContent>
    </IonPage>
  );
};

export default Slides;
