import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonInfiniteScroll, 
  IonInfiniteScrollContent,
  IonButton,
  IonList,
  IonItem,
  IonLabel, 
   useIonViewWillEnter} from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab2.css';
import { useState} from 'react';

const Tab2: React.FC = () => {
  const czyPierwsza = (n: number) => {
    
    if(n<2)
      return false;
  
    for(let i=2;i*i<=n;i++)
      if(n%i==0)
        return false; 
    return true;
  }
  
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [data, setData] = useState<string[]>([]);
  const [number, setNumber] = useState<number>(0);

  const pushData = () => {
    const max = number + 100;
    const min = max - 100 ;

    const newData :  string[] = [];
    for (let i = min; i < max; i++) {
      if(czyPierwsza(i)){
        newData.push('Item' + i);
      }
    }
    setNumber(max)
    
    setData([
      ...data,
      ...newData
    ]);
  }
  const loadData = (ev: any) => {
    setTimeout(() => {
      pushData();
      console.log('Loaded data');
      ev.target.complete();
      if (data.length === 1000) {
        setInfiniteDisabled(true);
      }
    }, 500);
  }  

  useIonViewWillEnter(() => {
    pushData();
  });

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Tab 2</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>


        <IonButton onClick={() => setInfiniteDisabled(!isInfiniteDisabled)} expand="block">
          Toggle Infinite Scroll
        </IonButton>
        
        <IonList>
          {data.map((item, index) => {
            return (
              <IonItem key={index}>
                <IonLabel>{item}</IonLabel>
              </IonItem>
            )
          })}
        </IonList>

        <IonInfiniteScroll
          onIonInfinite={loadData}
          threshold="100px"
          disabled={isInfiniteDisabled}
        >
          <IonInfiniteScrollContent
            loadingSpinner="bubbles"
            loadingText="Loading more data..."
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
      </IonContent>
    </IonPage>
  );
};

export default Tab2;
