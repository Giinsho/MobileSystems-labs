import { IonIcon } from "@ionic/react";
import React from "react";
import { useState, useEffect, useRef } from "react";
import "./Form.css";
import { useForm } from "react-hook-form";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonInput,
  IonTitle,
  IonButton,
  IonItem,
  IonSlides,
  IonSlide,
  IonLabel,
} from "@ionic/react";
import { type } from "os";
const Form: React.FC = () => {
  const slidesRef = useRef<any>();
  const [slideChange, setChange] = useState<any>();
  const opts = {
    initialSlide: 0,
    speed: 300,
    allowTouchMove: false,
  };

  const [state, setState] = useState<any>({
    imie: "",
    nazwisko: "",
    email: "",
    haslo: "",
    phoneNumber: "",
  });

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
    clearErrors
  } = useForm();

  const change = (e: any) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };

  const metodaForm = (e: any) => {
    e.preventDefault();
    console.log(state);
  };


  const onBtnClicked = async (direction: string) => {
 
    const swiper = await slidesRef.current.getSwiper();
    if (direction === "next") {
      console.log(swiper.activeIndex)
      if(swiper.activeIndex == 0){
        if (Object.keys(state.imie).length != 0 && Object.keys(state.nazwisko).length != 0) {
          clearErrors('nazwisko');
          clearErrors('imie');
          swiper.slideNext();
          return ;
        } else if(Object.keys(state.imie).length == 0){
          [
            {
              type: "manual",
              name: "imie",
              message: "Wymagane Imie",
            }
          ].forEach(({ name, type, message }) =>
          setError(name, { type, message })
         )
        } else if(Object.keys(state.nazwisko).length == 0){
          [
            {
              type: "manual",
              name: "nazwisko",
              message: "Wymagane Nazwisko",
            }
          ].forEach(({ name, type, message }) =>
          setError(name, { type, message })
         )
        }
      }
     
      if(swiper.activeIndex == 1){
     
        if (Object.keys(state.haslo).length >= 6) {
          clearErrors('haslo');
          swiper.slideNext();
          return ;
        } else if(Object.keys(state.haslo).length >= 0 &&  Object.keys(state.haslo).length < 6){

          [
            {
              type: "manual",
              name: "haslo",
              message: "Wymagane conamniej 6 znaków",
            }
          ].forEach(({ name, type, message }) =>
          setError(name, { type, message })
         )
        }
      }

      if(swiper.activeIndex == 2){
        if (Object.keys(state.imie).length != 0 && Object.keys(state.nazwisko).length != 0&& Object.keys(state.email).length != 0 && Object.keys(state.phoneNumber).length != 0 && Object.keys(state.haslo).length != 0) {
          clearErrors('nazwisko');
          clearErrors('imie');
          clearErrors('haslo');
          clearErrors('phoneNumber');
          clearErrors('email');
          swiper.slideNext();
          return ;
        } else if(Object.keys(state.email).length == 0 ){

          [
            {
              type: "manual",
              name: "email",
              message: "To pole nie może być puste",
            }
          ].forEach(({ name, type, message }) =>
          setError(name, { type, message })
         )
        } else if(Object.keys(state.phoneNumber).length == 0 ){

          [
            {
              type: "manual",
              name: "phoneNumber",
              message: "Wymagany numer telefonu",
            }
          ].forEach(({ name, type, message }) =>
          setError(name, { type, message })
         )
        }
      }
     


    } else if (direction === "prev") {
      swiper.slidePrev();
    }
  };

  return (
    <IonPage>
      <IonHeader collapse="condense">
        <IonToolbar>
          <IonTitle size="large">Form</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent fullscreen>
        <form
          onSubmit={handleSubmit(metodaForm)}
          style={{ width: "100%", height: "100%" }}
        >
          <IonSlides
            options={opts}
            ref={slidesRef}
            onIonSlideDidChange={slideChange}
            pager={true}
            style={{ width: "100%", height: "90%", marginTop: "5%" }}
          >
            <IonSlide>
              <div style={{ width: "20%", height: "90%" }}>
                <IonItem color="tertiary">
                  <IonLabel position="floating">Imie</IonLabel>
                  <IonInput
                    placeholder="Imie"
                    type="text"
                    {...register("imie", { required: true })}
                    onIonChange={change}
                    name="imie"
                  />
                  {errors.imie && <p>{errors.imie.message}</p> }
                </IonItem>
                <br />
                <IonItem color="tertiary">
                  <IonLabel position="floating">Nazwisko</IonLabel>
                  <IonInput
                    placeholder="Nazwisko"
                    {...register("nazwisko", { required: true })}
                    type="text"
                    name="nazwisko"
                    onIonChange={change}
                  ></IonInput>
                  {errors.nazwisko && <p>{errors.nazwisko.message}</p>}
                </IonItem>
                <IonButton type="button" 
                
                onClick={() => onBtnClicked("next")}>
                  Next
                </IonButton>
              </div>
            </IonSlide>

            <IonSlide>
              <div style={{ width: "20%", height: "90%" }}>
                <IonItem color="tertiary">
                  <IonLabel position="floating">Hasło</IonLabel>
                  <IonInput
                    placeholder="Hasło"
                    type="password"
                    {...register("haslo", { required: true })}
                    name="haslo"
                    onIonChange={change}
                  ></IonInput>
                  {errors.haslo && <p>{errors.haslo.message}</p>}
                </IonItem>
                <IonButton type="button" 
                onClick={() => onBtnClicked("prev")}>
                  Prev
                </IonButton>
                <IonButton type="button" 
                onClick={() => onBtnClicked("next")}>
                  Next
                </IonButton>
              </div>
            </IonSlide>

            <IonSlide>
              <div style={{ width: "30%", height: "90%" }}>
                <IonItem color="tertiary">
                  <IonLabel position="floating">Email</IonLabel>
                  <IonInput
                    placeholder="Email"
                    type="text"
                    {...register("email", { required: true })}
                    name="email"
                    onIonChange={change}
                  ></IonInput>
                  {errors.email && <p>{errors.email.message}</p>}
                </IonItem>
                <br />

                <IonItem color="tertiary">
                  <IonLabel position="floating">Nr telefonu</IonLabel>
                  <IonInput
                    placeholder="Phone number"
                    type="tel"
                    {...register("phoneNumber", { required: true })}
                    name="phoneNumber"
                    onIonChange={change}
                  ></IonInput>
                  {errors.phoneNumber && <p>{errors.phoneNumber.message}</p>}
                </IonItem>
                <IonButton type="button" 
                  onClick={() => onBtnClicked("prev")}>
                    Prev
                </IonButton>
                <IonButton type="submit" className="ion-margin-top" expand="block"  onClick={() => onBtnClicked("next")}>
                  Submit
               </IonButton>
              </div>
            </IonSlide>


            <IonSlide>
              <div style={{ width: "30%", height: "90%" }}>
                <IonHeader>
                  <IonTitle>
                    Wypełniony formularz
                  </IonTitle>
                  
                </IonHeader>
                <br/>

              <IonLabel>Imie</IonLabel>
                <IonItem color="tertiary">
                  <IonInput
                    type="text"
                    readonly
                  >{state.imie}</IonInput>
                </IonItem>
                <br />

                <IonLabel>Nazwisko</IonLabel>
                <IonItem color="tertiary">
                  <IonInput
                    type="text"
                    readonly
                  >{state.nazwisko}</IonInput>
                </IonItem>
                <br />

                <IonLabel>Email</IonLabel>
                <IonItem color="tertiary">
                  <IonInput
                    type="text"
                    readonly
                  >{state.email}</IonInput>
                </IonItem>
                <br />

                <IonLabel>Nr telefonu</IonLabel>
                <IonItem color="tertiary">
                  <IonInput
                    type="tel"
                    readonly
                  >{state.phoneNumber}</IonInput>
                </IonItem>
                <br />
                <IonButton onClick={() => onBtnClicked("prev")}>
                    Prev
               </IonButton>
              </div>
            </IonSlide>

            
          </IonSlides>
        </form>
      </IonContent>
    </IonPage>
  );
};
export default Form;
