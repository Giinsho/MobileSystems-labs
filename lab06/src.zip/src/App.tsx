import { Redirect, Route } from 'react-router-dom';
import {
  IonApp,
  IonIcon,
  IonLabel,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  setupIonicReact,
  IonItem
} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { ellipse, square, triangle, egg, cart, football, recording, addCircle, squareSharp, phoneLandscape, phonePortrait, contractOutline, phonePortraitOutline, listCircleOutline, folderOutline, calculator, shieldCheckmark, arrowForwardCircle } from 'ionicons/icons';
import Tab1 from './pages/Tab1';
import Tab2 from './pages/Tab2';
import Tab3 from './pages/Tab3';
import Kalkulator from './pages/Kalkulator';
/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';

/* Theme variables */
import './theme/variables.css';
import Following from './pages/Following';
import Lists from './pages/Lists';
import Form from './pages/Form';
import Area from "./pages/Area";
import Slides from "./pages/Slides";
setupIonicReact();

const App: React.FC = () => (
  <IonApp>
    <IonReactRouter>
      <IonTabs>
        <IonRouterOutlet>
          <Route exact path="/">
            <Redirect to="/tab1" />
          </Route>

          <Route exact path="/tab1">
            <Tab1 />
          </Route>
          <Route exact path="/tab2">
            <Tab2 />
          </Route>
          <Route path="/tab3">
            <Tab3 />
          </Route>

          <Route path="/kalkulator">
            <Kalkulator/>
          </Route>

          <Route path="/list">
            <Lists/>
          </Route>

          <Route path="/following">
            <Following/>
          </Route>

          <Route path="/poleczworokata">
            <Area />
          </Route>

          <Route path="/slides-lab6">
            <Slides/>
          </Route>



          <Route exact path="/register">
            <Form />
          </Route>



        

          



        </IonRouterOutlet>
      
        <IonTabBar slot="bottom">

          <IonTabButton tab="tab1" href="/tab1">
            <IonIcon icon={triangle} />
            <IonLabel>Tab 1</IonLabel>
          </IonTabButton>
          <IonTabButton tab="tab2" href="/tab2">
            <IonIcon icon={ellipse} />
            <IonLabel>Tab 2</IonLabel>
          </IonTabButton>
          <IonTabButton tab="tab3" href="/tab3">
            <IonIcon icon={square} />
            <IonLabel>Tab 3</IonLabel>
          </IonTabButton>
          <IonTabButton tab="kalkulator" href="/kalkulator">
            <IonIcon icon={calculator} />
            <IonLabel>Kalkulator</IonLabel>
          </IonTabButton>
          <IonTabButton tab="List" href="/list">
            <IonIcon icon={listCircleOutline} />
            <IonLabel>List</IonLabel>
          </IonTabButton>
          <IonTabButton tab="Following" href="/following">
            <IonIcon icon={folderOutline} />
            <IonLabel>Following</IonLabel>
          </IonTabButton>
          <IonTabButton tab="Pole czworokąta" href="/poleczworokata">
            <IonIcon icon={squareSharp} />
            <IonLabel>Pole czworokąta</IonLabel>
          </IonTabButton>

          <IonTabButton tab="Slides" href="/slides-lab6">
            <IonIcon icon={arrowForwardCircle} />
            <IonLabel>Slides</IonLabel>
          </IonTabButton>
    
      
       



          <IonTabButton tab="Register" href="/register">
            <IonIcon icon={addCircle} />
            <IonLabel>Register</IonLabel>
          </IonTabButton>
        </IonTabBar>
      </IonTabs>
    </IonReactRouter>
  </IonApp>
);

export default App;
