export const people = [
    {
        id: 0,
        name: "Arek",
        surname: "Arkowski",
        avatar: "../img/1.png",
        following: false
     },
     {
        id: 1,
        name: "Marek",
        surname: "Markowski",
        avatar: "../img/1.png",
        following: true
     },
     {
        id: 2,
        name: "Darek",
        surname: "Darkowski",
        avatar: "../img/3.png",
        following: false
     }
    ];